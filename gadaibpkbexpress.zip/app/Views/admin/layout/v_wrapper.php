<?php 

echo view('admin/layout/v_head.php');
echo view('admin/layout/v_header.php');
echo view('admin/layout/v_nav.php');
echo view('admin/layout/v_content.php');
echo view('admin/layout/v_footer.php');

?>