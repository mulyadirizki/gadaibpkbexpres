<body>

  <!--==========================
  Header
  ============================-->
  <header id="header" class="fixed-top">
    <div class="container">

      <div class="logo float-left">
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <h1 class="text-light"><a href="#header"><span>NewBiz</span></a></h1> -->
        <!-- <a href="#intro" class="scrollto"><img src="http://localhost:8080/assets/img/logo.png" alt="" class="img-fluid"></a> -->
        <h3 style="color: skyblue; font-weight: bold; text-decoration: underline;">Gadai BPKB - Seluruh Riau</h3>
      </div>

      <nav class="main-nav float-right d-none d-lg-block">
        <ul>
          <li class=""><a href="<?= base_url() ?>">Home</a></li>
          <li><a href="<?= base_url() ?>#services">Gadai BPKB Kendaraan</a></li>
          <li><a href="<?= base_url() ?>#about">Persyaratan</a></li>
          <li><a href="<?= base_url() ?>/proses-kredit">Proses Kredit</a></li>
          <li><a href="<?= base_url() ?>#contact">Kontak Kami</a></li>
        </ul>
      </nav><!-- .main-nav -->
      
    </div>
  </header><!-- #header -->