<?php 

    echo view('front/v_head.php');
    echo view('front/v_header.php');
    echo view('front/v_content.php');
    echo view('front/v_footer.php');

?>