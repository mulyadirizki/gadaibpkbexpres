<?php namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\M_profile;
use App\Models\M_front;

class C_front extends Controller
{

	public function __construct()
    {
        $this->profile = new M_profile();
        $this->message = new M_front();  
    }

    public function pengajuan()
    {
        helper('form');
        $data = [
            'title' => 'GADAI BPKB EXPRESS',
            'isi'   => 'front/pengajuan',
            'profile' => $this->profile->getProfile()
        ];

        return view('front/v_wrapper', $data);
    }

    public function process()
    {
        $name = htmlspecialchars($this->request->getPost('name'));
        $email = htmlspecialchars($this->request->getPost('email'));
        $subject = htmlspecialchars($this->request->getPost('subject'));
        $message = htmlspecialchars($this->request->getPost('message'));

        $data = [
            'name' => $name,
            'email' => $email,
            'subject' => $subject,
            'message' => $message,
        ];

        $simpan = $this->message->insertMessage($data);
        if($simpan)
        {
            session()->setFlashdata('success', 'Pesan Berhasil Terkirim');
            return redirect()->to(base_url('/')); 
        }
    }

    public function delete($id_message)
    {
        $hapus = $this->message->deleteMessage($id_message);
        if($hapus)
        {
            session()->setFlashdata('success', 'Deleted Profile successfully');
            return redirect()->to(base_url('administrator/message')); 
        }
    }
	//--------------------------------------------------------------------

}
